package com.company.springboot.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.company.springboot.entity.UserEntity;

public interface UserRepository extends JpaRepository<UserEntity, String> {

	UserEntity findByUsername(String username);

}
