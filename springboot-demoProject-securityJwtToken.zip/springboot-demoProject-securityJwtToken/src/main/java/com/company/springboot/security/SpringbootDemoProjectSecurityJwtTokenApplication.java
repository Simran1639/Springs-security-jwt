package com.company.springboot.security;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringbootDemoProjectSecurityJwtTokenApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringbootDemoProjectSecurityJwtTokenApplication.class, args);
	}

}
