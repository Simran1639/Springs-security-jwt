package com.company.springboot.securityJWT;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringbootSecurityExampleWithJwtAuthApplicationTests {

	@Test
	void contextLoads() {
	}

}
